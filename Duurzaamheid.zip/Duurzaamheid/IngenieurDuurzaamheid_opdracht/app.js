const express = require("express");
const path = require("path");
const { MongoClient } = require("mongodb");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = process.env.DB_NAME || "carpool_platform";
const COLLECTION_NAME = process.env.COLLECTION_NAME || "survey_responses";

let surveyCollection;

async function connectToMongo() {
    if (!MONGODB_URI) {
        throw new Error("MONGODB_URI ontbreekt in je .env bestand.");
    }

    const client = new MongoClient(MONGODB_URI);
    await client.connect();

    const db = client.db(DB_NAME);
    surveyCollection = db.collection(COLLECTION_NAME);

    console.log(`Verbonden met MongoDB database: ${DB_NAME}`);
}

app.get("/", (req, res) => {
    res.render("home", { title: "Carpool Platform" });
});

app.get("/survey", (req, res) => {
    res.render("survey", { title: "Mobiliteitsbevraging" });
});

app.post("/api/survey", async (req, res) => {
    try {
        const { answers, visiblePath } = req.body;

        if (!answers || typeof answers !== "object") {
            return res.status(400).json({
                success: false,
                message: "Ongeldige antwoorden ontvangen."
            });
        }

        const document = {
            answers,
            visiblePath: Array.isArray(visiblePath) ? visiblePath : [],
            createdAt: new Date(),
            userAgent: req.get("user-agent") || null,
            ip:
                req.headers["x-forwarded-for"]?.toString().split(",")[0].trim() ||
                req.socket.remoteAddress ||
                null
        };

        const result = await surveyCollection.insertOne(document);

        res.status(201).json({
            success: true,
            message: "Survey succesvol opgeslagen.",
            insertedId: result.insertedId
        });
    } catch (error) {
        console.error("Fout bij opslaan in MongoDB:", error);
        res.status(500).json({
            success: false,
            message: "Er ging iets mis bij het opslaan."
        });
    }
});

async function startServer() {
    try {
        await connectToMongo();

        app.listen(PORT, () => {
            console.log(`Server draait op http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("Kon server niet starten:", error);
        process.exit(1);
    }
}

startServer();